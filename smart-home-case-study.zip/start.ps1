Write-Host "Starte Smart-Home-Anwendung..."
docker compose up --build -d
Write-Host "Fertig. Browser: http://localhost:5000"
Write-Host "PostgreSQL Host-Port: localhost:5001"
