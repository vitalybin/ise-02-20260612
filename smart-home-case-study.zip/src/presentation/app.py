import os
from flask import Flask, render_template, request, redirect, session, flash
from werkzeug.security import check_password_hash
from src.infrastructure.database import init_db
from src.infrastructure.repositories import SqlRepository
from src.application.services import SmartHomeUseCases, load_permissions
app=Flask(__name__); app.secret_key=os.getenv('FLASK_SECRET_KEY','dev')
repo=SqlRepository(); uc=SmartHomeUseCases(repo)
def current_user(): return session.get('user')
@app.before_request
def boot():
    if not getattr(app,'db_ready',False): init_db(); app.db_ready=True
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=repo.user_by_username(request.form['username'])
        if u and check_password_hash(u['password_hash'],request.form['password']): session['user']=load_permissions(dict(u)); return redirect('/')
        flash('Login fehlgeschlagen')
    return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect('/login')
@app.route('/')
def index():
    if not current_user(): return redirect('/login')
    return render_template('index.html',user=current_user(),rooms=repo.all_rooms(),devices=repo.devices(request.args.get('status') or None))
@app.post('/devices/create')
def create_device(): repo.save_device(request.form['name'],request.form['device_type']); return redirect('/')
@app.post('/devices/install')
def install_device():
    try: uc.install_device(current_user(),int(request.form['device_id']),int(request.form['room_id'])); flash('Gerät installiert')
    except Exception as e: flash(str(e))
    return redirect('/')
@app.post('/devices/control')
def control_device():
    try: uc.control_device(current_user(),int(request.form['device_id']),request.form['action']); flash('Gerät gesteuert')
    except Exception as e: flash(str(e))
    return redirect('/')
@app.post('/devices/advanced')
def advanced():
    try: uc.advanced_config(current_user(),int(request.form['device_id']),request.form['key'],request.form['value']); flash('Erweiterte Konfiguration gespeichert')
    except Exception as e: flash(str(e))
    return redirect('/')
@app.route('/admin',methods=['GET','POST'])
def admin():
    if not current_user(): return redirect('/login')
    if request.method=='POST':
        try:
            action=request.form['action']
            if action=='backup': flash('Backup: '+uc.create_backup(current_user()))
            elif action=='export': flash('Export: '+uc.create_export(current_user(),'system',request.form.get('fmt','json')))
            elif action=='user': uc.create_user(current_user(),request.form['username'],request.form['password'],request.form['display_name'],request.form['role']); flash('Benutzer angelegt')
        except Exception as e: flash(str(e))
    return render_template('admin.html',user=current_user(),users=repo.users(),jobs=repo.backup_jobs())
if __name__=='__main__': app.run(host='0.0.0.0',port=5000,debug=True)
