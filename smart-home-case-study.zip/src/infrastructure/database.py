import os, time
import psycopg2
from psycopg2.extras import RealDictCursor, Json
from werkzeug.security import generate_password_hash

def conn():
    return psycopg2.connect(host=os.getenv('DB_HOST','localhost'), port=os.getenv('DB_PORT','5001'), dbname=os.getenv('DB_NAME','smarthome'), user=os.getenv('DB_USER','smarthome'), password=os.getenv('DB_PASSWORD','smarthome'), cursor_factory=RealDictCursor)

def init_db():
    for _ in range(40):
        try:
            c=conn(); c.close(); break
        except Exception: time.sleep(1)
    sql = """
    CREATE TABLE IF NOT EXISTS roles(id SERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL);
    CREATE TABLE IF NOT EXISTS permissions(id SERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL);
    CREATE TABLE IF NOT EXISTS role_permissions(role_id INT REFERENCES roles(id), permission_id INT REFERENCES permissions(id), PRIMARY KEY(role_id,permission_id));
    CREATE TABLE IF NOT EXISTS rooms(id SERIAL PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS devices(id SERIAL PRIMARY KEY, name TEXT NOT NULL, device_type TEXT NOT NULL, status TEXT NOT NULL, room_id INT REFERENCES rooms(id), configuration JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMP DEFAULT now());
    CREATE TABLE IF NOT EXISTS users(id SERIAL PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, display_name TEXT NOT NULL, role_id INT REFERENCES roles(id), active BOOLEAN DEFAULT TRUE);
    CREATE TABLE IF NOT EXISTS backup_jobs(id SERIAL PRIMARY KEY, job_type TEXT NOT NULL, file_path TEXT, created_by TEXT, created_at TIMESTAMP DEFAULT now(), status TEXT NOT NULL);
    """
    with conn() as c, c.cursor() as cur:
        cur.execute(sql)
        roles=['VIEWER','TECHNIKER','ADMIN']; perms=['RAUM_LESEN','GERAET_LESEN','GERAET_INSTALLIEREN','GERAET_STEUERN','GERAET_KONFIGURIEREN','GERAET_KALIBRIEREN','GERAET_ERWEITERT_STEUERN','USER_VERWALTEN','DATEN_BACKUP_EXPORT_IMPORT']
        for r in roles: cur.execute('INSERT INTO roles(name) VALUES(%s) ON CONFLICT DO NOTHING',(r,))
        for p in perms: cur.execute('INSERT INTO permissions(name) VALUES(%s) ON CONFLICT DO NOTHING',(p,))
        mapping={'VIEWER':['RAUM_LESEN','GERAET_LESEN'], 'TECHNIKER':['RAUM_LESEN','GERAET_LESEN','GERAET_INSTALLIEREN','GERAET_STEUERN','GERAET_KONFIGURIEREN','GERAET_KALIBRIEREN'], 'ADMIN':perms}
        for r,ps in mapping.items():
            for p in ps: cur.execute('INSERT INTO role_permissions SELECT r.id,p.id FROM roles r, permissions p WHERE r.name=%s AND p.name=%s ON CONFLICT DO NOTHING',(r,p))
        cur.execute('SELECT count(*) c FROM rooms')
        if cur.fetchone()['c']==0:
            for name in ['Wohnzimmer','Küche','Schlafzimmer','Büro','Flur']:
                cur.execute('INSERT INTO rooms(name,description) VALUES(%s,%s)',(name,'Beispielraum '+name))
            data=[('Deckenlampe','LAMPE','INSTALLIERT',1,{'power':'off','helligkeit':70}),('Thermostat','HEIZUNG','INSTALLIERT',1,{'zieltemperatur':21}),('Fenstersensor','SENSOR','NICHT_INSTALLIERT',None,{}),('Kamera Eingang','KAMERA','DEFEKT',None,{}),('Steckdose Küche','STECKDOSE','BESTELLT',None,{})]
            for d in data: cur.execute('INSERT INTO devices(name,device_type,status,room_id,configuration) VALUES(%s,%s,%s,%s,%s)',(d[0],d[1],d[2],d[3],Json(d[4])))
        for u,pw,disp,role in [('admin','admin123','Administrator','ADMIN'),('tech','tech123','Techniker','TECHNIKER'),('viewer','viewer123','Viewer','VIEWER')]:
            cur.execute('INSERT INTO users(username,password_hash,display_name,role_id) SELECT %s,%s,%s,id FROM roles WHERE name=%s ON CONFLICT(username) DO NOTHING',(u,generate_password_hash(pw),disp,role))
