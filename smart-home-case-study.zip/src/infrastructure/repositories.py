from .database import conn
from psycopg2.extras import Json
class SqlRepository:
    def all_rooms(self):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT * FROM rooms ORDER BY id'); return cur.fetchall()
    def devices(self,status=None):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT d.*, r.name room_name FROM devices d LEFT JOIN rooms r ON r.id=d.room_id WHERE (%s IS NULL OR d.status=%s) ORDER BY d.id',(status,status)); return cur.fetchall()
    def device(self,id):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT * FROM devices WHERE id=%s',(id,)); return cur.fetchone()
    def save_device(self,name,typ):
        with conn() as c, c.cursor() as cur: cur.execute('INSERT INTO devices(name,device_type,status) VALUES(%s,%s,%s)',(name,typ,'NICHT_INSTALLIERT'))
    def update_device(self,id,**kw):
        sets=[]; vals=[]
        for k,v in kw.items():
            if k in {'status','room_id','configuration','name'}: sets.append(f'{k}=%s'); vals.append(Json(v) if k=='configuration' else v)
        if not sets: return
        vals.append(id)
        with conn() as c, c.cursor() as cur: cur.execute(f"UPDATE devices SET {', '.join(sets)} WHERE id=%s",vals)
    def users(self):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT u.id,u.username,u.display_name,r.name role,u.active FROM users u JOIN roles r ON r.id=u.role_id ORDER BY u.id'); return cur.fetchall()
    def user_by_username(self,username):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT u.*, r.name role FROM users u JOIN roles r ON r.id=u.role_id WHERE username=%s AND active=true',(username,)); return cur.fetchone()
    def create_user(self,username,password_hash,display_name,role):
        with conn() as c, c.cursor() as cur: cur.execute('INSERT INTO users(username,password_hash,display_name,role_id) SELECT %s,%s,%s,id FROM roles WHERE name=%s ON CONFLICT(username) DO NOTHING',(username,password_hash,display_name,role))
    def log_job(self,job_type,path,user,status='ERFOLGREICH'):
        with conn() as c, c.cursor() as cur: cur.execute('INSERT INTO backup_jobs(job_type,file_path,created_by,status) VALUES(%s,%s,%s,%s)',(job_type,path,user,status))
    def backup_jobs(self):
        with conn() as c, c.cursor() as cur: cur.execute('SELECT * FROM backup_jobs ORDER BY id DESC'); return cur.fetchall()
