import os, json, csv, datetime
from werkzeug.security import generate_password_hash
from src.infrastructure.database import conn
class BerechtigungsService:
    @staticmethod
    def require(user,permission):
        if not user or permission not in user.get('permissions',[]): raise PermissionError('Keine Berechtigung')
def load_permissions(user):
    with conn() as c, c.cursor() as cur:
        cur.execute('SELECT p.name FROM users u JOIN roles r ON r.id=u.role_id JOIN role_permissions rp ON rp.role_id=r.id JOIN permissions p ON p.id=rp.permission_id WHERE u.id=%s',(user['id'],))
        user['permissions']=[x['name'] for x in cur.fetchall()]
    return user
class SmartHomeUseCases:
    def __init__(self,repo): self.repo=repo
    def install_device(self,user,device_id,room_id):
        BerechtigungsService.require(user,'GERAET_INSTALLIEREN'); d=self.repo.device(device_id)
        if not d or d['status']!='NICHT_INSTALLIERT' or d['room_id'] is not None: raise ValueError('Gerät darf nicht installiert werden')
        self.repo.update_device(device_id,status='INSTALLIERT',room_id=room_id)
    def control_device(self,user,device_id,action):
        BerechtigungsService.require(user,'GERAET_STEUERN'); d=self.repo.device(device_id)
        if not d or d['status']!='INSTALLIERT': raise ValueError('Gerät ist nicht steuerbar')
        cfg=dict(d['configuration'] or {}); cfg['power']='on' if action=='on' else 'off'; self.repo.update_device(device_id,configuration=cfg)
    def advanced_config(self,user,device_id,key,value):
        BerechtigungsService.require(user,'GERAET_ERWEITERT_STEUERN'); d=self.repo.device(device_id); cfg=dict(d['configuration'] or {}); cfg[key]=value; self.repo.update_device(device_id,configuration=cfg)
    def create_export(self,user,kind='system',fmt='json'):
        BerechtigungsService.require(user,'DATEN_BACKUP_EXPORT_IMPORT')
        data={'rooms':self.repo.all_rooms(),'devices':self.repo.devices(),'users':self.repo.users()}
        folder=os.getenv('EXCHANGE_DIR','/exchange'); os.makedirs(folder,exist_ok=True); ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); path=os.path.join(folder,f'{kind}_{ts}.{fmt}')
        if fmt=='csv':
            with open(path,'w',newline='',encoding='utf-8') as f: writer=csv.DictWriter(f,fieldnames=data['devices'][0].keys() if data['devices'] else ['id']); writer.writeheader(); writer.writerows(data['devices'])
        else:
            with open(path,'w',encoding='utf-8') as f: json.dump(data,f,default=str,indent=2,ensure_ascii=False)
        self.repo.log_job('EXPORT',path,user['username']); return path
    def create_backup(self,user):
        path=self.create_export(user,'backup','json'); self.repo.log_job('BACKUP',path,user['username']); return path
    def import_json(self,user,file_path):
        BerechtigungsService.require(user,'DATEN_BACKUP_EXPORT_IMPORT')
        with open(file_path,encoding='utf-8') as f: data=json.load(f)
        ids=set()
        for d in data.get('devices',[]):
            for k in ['name','device_type','status']:
                if k not in d: raise ValueError('Pflichtfeld fehlt: '+k)
            if d.get('id') in ids: raise ValueError('Doppelte Geräte-ID')
            ids.add(d.get('id'))
            if d.get('status')=='INSTALLIERT' and not d.get('room_id'): raise ValueError('Installierte Geräte benötigen Raum')
        self.repo.log_job('IMPORT',file_path,user['username']); return True
    def create_user(self,user,username,password,display_name,role):
        BerechtigungsService.require(user,'USER_VERWALTEN'); self.repo.create_user(username,generate_password_hash(password),display_name,role)
