from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, Any, List

class GeraeteStatus(str, Enum):
    BESTELLT='BESTELLT'; NICHT_INSTALLIERT='NICHT_INSTALLIERT'; INSTALLIERT='INSTALLIERT'; DEFEKT='DEFEKT'
class GeraeteTyp(str, Enum):
    LAMPE='LAMPE'; HEIZUNG='HEIZUNG'; SENSOR='SENSOR'; STECKDOSE='STECKDOSE'; KAMERA='KAMERA'
class Rolle(str, Enum):
    VIEWER='VIEWER'; TECHNIKER='TECHNIKER'; ADMIN='ADMIN'
class Berechtigung(str, Enum):
    RAUM_LESEN='RAUM_LESEN'; GERAET_LESEN='GERAET_LESEN'; GERAET_INSTALLIEREN='GERAET_INSTALLIEREN'; GERAET_STEUERN='GERAET_STEUERN'; GERAET_KONFIGURIEREN='GERAET_KONFIGURIEREN'; GERAET_KALIBRIEREN='GERAET_KALIBRIEREN'; GERAET_ERWEITERT_STEUERN='GERAET_ERWEITERT_STEUERN'; USER_VERWALTEN='USER_VERWALTEN'; DATEN_BACKUP_EXPORT_IMPORT='DATEN_BACKUP_EXPORT_IMPORT'

ROLE_PERMISSIONS={
    Rolle.VIEWER:{Berechtigung.RAUM_LESEN,Berechtigung.GERAET_LESEN},
    Rolle.TECHNIKER:{Berechtigung.RAUM_LESEN,Berechtigung.GERAET_LESEN,Berechtigung.GERAET_INSTALLIEREN,Berechtigung.GERAET_STEUERN,Berechtigung.GERAET_KONFIGURIEREN,Berechtigung.GERAET_KALIBRIEREN},
    Rolle.ADMIN:set(Berechtigung)
}
@dataclass
class Raum:
    id: Optional[int]; name: str; description: str=''; installierteGeraete: List['SmartGeraet']=field(default_factory=list)
@dataclass
class SmartGeraet:
    id: Optional[int]; name: str; device_type: GeraeteTyp; status: GeraeteStatus=GeraeteStatus.NICHT_INSTALLIERT; room_id: Optional[int]=None; configuration: Dict[str,Any]=field(default_factory=dict)
    def einschalten(self): self.configuration['power']='on'
    def ausschalten(self): self.configuration['power']='off'
    def konfigurieren(self,data): self.configuration.update(data)
    def kalibrieren(self): self.configuration['calibrated']=True
    def istSteuerbar(self): return self.status==GeraeteStatus.INSTALLIERT
class SmartLampe(SmartGeraet):
    def helligkeitAendern(self, wert:int): self.configuration['helligkeit']=wert
    def farbeAendern(self, farbe:str): self.configuration['farbe']=farbe
class SmartHeizung(SmartGeraet):
    def zieltemperaturSetzen(self, temp:float): self.configuration['zieltemperatur']=temp
class SmartSensor(SmartGeraet):
    def messwertAuslesen(self): return self.configuration.get('messwert',0)
class SmartSteckdose(SmartGeraet):
    def stromverbrauchAuslesen(self): return self.configuration.get('verbrauch_w',0)
class SmartKamera(SmartGeraet):
    def modusAendern(self, modus:str): self.configuration['modus']=modus
class SmartGeraetFactory:
    @staticmethod
    def create(typ, name):
        t=GeraeteTyp(typ); cls={GeraeteTyp.LAMPE:SmartLampe,GeraeteTyp.HEIZUNG:SmartHeizung,GeraeteTyp.SENSOR:SmartSensor,GeraeteTyp.STECKDOSE:SmartSteckdose,GeraeteTyp.KAMERA:SmartKamera}[t]
        return cls(None,name,t)
class GeraeteRegelService:
    @staticmethod
    def darfInstalliertWerden(device): return device and device['status']=='NICHT_INSTALLIERT' and device['room_id'] is None
    @staticmethod
    def darfGesteuertWerden(device): return device and device['status']=='INSTALLIERT'
@dataclass
class User:
    id: Optional[int]; username: str; password_hash: str; display_name: str; role: Rolle; active: bool=True
    def besitztBerechtigung(self,b): return b in ROLE_PERMISSIONS[self.role]
