# Architektur

DDD-Schichten: Presentation, Application, Domain, Infrastructure. SQL-Persistenz über PostgreSQL im separaten Container.
