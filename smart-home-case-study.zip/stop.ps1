Write-Host "Stoppe Smart-Home-Anwendung..."
docker compose down
Write-Host "Container gestoppt. Volumes bleiben erhalten."
