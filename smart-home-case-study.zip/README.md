# Smart-Home-Verwaltung

Lokale Docker-Webanwendung zur Verwaltung von Räumen, Smart-Geräten, Rollen/Rechten sowie Backup, Export und Import.

## Start

```powershell
./start.ps1
```

Dann öffnen: `http://localhost:5000`

## Login

- Admin: `admin` / `admin123`
- Techniker: `tech` / `tech123`
- Viewer: `viewer` / `viewer123`

## Stoppen

```powershell
./stop.ps1
```

Die Datenbank läuft in einem eigenen PostgreSQL-Container und ist über `localhost:5001` erreichbar. Das Projektverzeichnis ist als Volume Share im App-Container eingebunden; Backups/Exports liegen im `app-exchange-volume`.
